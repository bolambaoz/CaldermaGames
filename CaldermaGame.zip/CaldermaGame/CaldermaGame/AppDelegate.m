//
//  AppDelegate.m
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//

#import "AppDelegate.h"
#import "Page1ViewController.h"
@interface AppDelegate ()

@property (strong, nonatomic) UINavigationController *navController;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    Page1ViewController *frstVwCntlr = [Page1ViewController new];
    self.navController = [[UINavigationController alloc] initWithRootViewController:frstVwCntlr];
    self.window.rootViewController = self.navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}



@end
