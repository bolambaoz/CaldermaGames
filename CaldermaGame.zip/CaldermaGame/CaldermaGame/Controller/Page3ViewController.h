//
//  Page3ViewController.h
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//

#import <UIKit/UIKit.h>

@interface Page3ViewController : UIViewController

@property (assign, nonatomic) int  type;

@end
