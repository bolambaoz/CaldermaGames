//
//  Page3ViewController.m
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//

#import "Page3ViewController.h"
#import "Page1ViewController.h"

@interface Page3ViewController ()

@property (assign, nonatomic) NSArray * answers1;
@property (assign, nonatomic) NSArray * answer2;
@property (assign, nonatomic) NSArray * answer3;
@property (assign, nonatomic) NSArray * answers4;
@end

@implementation Page3ViewController{
    UITextField *Name;
    UITextField *Phone;
    UILabel     *timerLabel;
    UILabel     *finalScoreLabel, *titleTreatDetail, *titleTreat;
    
    UIButton *btnPlay, *btnSubmitAnswer;
    
    float width;
    float height;
    UIImageView *ivDestination2, *ivDestination1, *ivDestination3, *ivDestination4, *tempIV;
    
    UIImageView *ivSource1,*ivSource2,*ivSource3,*ivSource4,*ivSource5,*ivSource6;
    
    UIImageView *imgIsCorrect1,*imgIsCorrect2,*imgIsCorrect3,*imgIsCorrect4;
    
    int answerCount;
    int answerCorrectCount;
    int counter;
    
    UIImageView *currentTouch, *imgTimer;
    
    NSMutableArray *finalAnswers;
    
    NSArray *choice1,*choice2,*choice3,*choice4;
    NSArray *choice1label,*choice2label,*choice3label,*choice4label;
    
    NSTimer *gameTime;
    
    NSMutableArray *arrCorrect;
    
    UIView *scoreBoard;
    
    BOOL submitted;
    BOOL isHomeEnabled;
    
    NSArray *answers1Label,*answers2Label,*answers3Label,*answers4Label;
}
-(void)StartTime{
    NSLog(@"%@ :sec",[NSString stringWithFormat:@"%d",counter]);
    counter--;
    timerLabel.text = [NSString stringWithFormat:@"%d",counter];
    if(counter<=10){
        timerLabel.textColor = [UIColor redColor];
    }
    
    if(counter == 0){
        [gameTime invalidate];
        imgTimer.hidden = YES;
        timerLabel.hidden = YES;
        [self checkAnswers];
    }
}

- (void)checkAnswers{
    ivSource1.hidden = YES;
    ivSource2.hidden = YES;
    ivSource3.hidden = YES;
    ivSource4.hidden = YES;
    ivSource5.hidden = YES;
    ivSource6.hidden = YES;
    
    NSArray *arrCAns = [self correctAnsArray:self.type];
    NSArray *arrDetailAnswer = [self answerDetailLabelArray:self.type];
    
    for(int i=0;i<finalAnswers.count;i++){
        UIImageView *tempView = [self.view viewWithTag:700+i];
        tempView.hidden = NO;
        if(arrCAns[i]==finalAnswers[i]){
            tempView.image = [UIImage imageNamed:@"correct"];
            answerCorrectCount++;
        }else{
            tempView.image = [UIImage imageNamed:@"wrong"];
        }
        
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        self->btnSubmitAnswer.hidden = YES;
        self->finalScoreLabel.text = [NSString stringWithFormat:@"%d out of 4",self->answerCorrectCount];
        self->scoreBoard.hidden = NO;
    });
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        self->btnSubmitAnswer.hidden = YES;
        
        [UIView animateWithDuration:(NSTimeInterval)1.5 animations:^{
            self->titleTreat.frame  = CGRectMake(50, 200+100,self->width-((self->width/1.6)+95),52);
            self->titleTreatDetail.frame  = CGRectMake(50, 200+60+40,self->width-((self->width/1.6)+95),150);
        }];
        for(int i=0;i<arrCAns.count;i++){
            UIImageView *tempView2 = [self.view viewWithTag:700+i];
            tempView2.hidden = YES;
            UIImageView *tempView = [self.view viewWithTag:200+i];
            tempView.image = [UIImage imageNamed:arrCAns[i]];
            
            UILabel *tempLabel = [self.view viewWithTag:500+i];
            tempLabel.text = [NSString stringWithFormat:@"%@",arrDetailAnswer[i]];
            
            self->isHomeEnabled = YES;
        }
    });
}

- (void)VoidSubmitAnswer{
    [gameTime invalidate];
    submitted = YES;
    imgTimer.hidden = YES;
    timerLabel.hidden = YES;
    [self checkAnswers];
}
-(void)viewDidDisappear:(BOOL)animated{
    [gameTime invalidate];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    isHomeEnabled = NO;
    submitted = NO;
    imgTimer.hidden = NO;
    timerLabel.hidden = NO;

    gameTime = [NSTimer scheduledTimerWithTimeInterval: 1.0
                          target: self
                          selector:@selector(StartTime)
                          userInfo: nil repeats:YES];
    
    [self.navigationItem setHidesBackButton:YES];
    width =  self.view.frame.size.width;
    height = self.view.frame.size.height;
    float def1 = 200;
    answerCount = 0;
    answerCorrectCount = 0;
    counter = 34;
    finalAnswers = [NSMutableArray new];
    
    _answers1 = @[@"GCS1",@"AKLIEF1",@"SUN_SPF1",@"BENZAC1"];
    _answer2 = @[@"BHR_CREAMY_CLEANSER2",@"BENZOYL2",@"BHR_NIGHT_CREAM2",@"SUN_SPF2"];
    _answer3 = @[@"AD_DERMA3",@"DESONIDE3",@"AD_DERMA_MOISTURIZER3",@"SUN_SPF3"];
    _answers4 = @[@"BHR_CREAMY_CLEANSER4",@"BHR_CREAMY_CLEANSER4-1",@"TONER_&_MASK4",@"SPF_15_&_NIGHT4"];
    
    answers1Label = @[@"Gentle Skin Cleanser Gentle and hypoallergenic cleanser",@"Aklief (Trifarotene .005%) Reduces inflammation, clears acne bumps and blemishes, and redefines skin",@"Benzac Microbiome Equalizer Made with Probiotic-derived technology to hydrate skin",@"Cetaphil Sun SPF50+ Light Gel Light weight gel that protects skin from UVA and UVB rays"];
    
    answers2Label = @[@"Brightness Reveal Creamy Cleanser Non-drying cleanser that removes dead skin and impurities",@"Epiduo Forte (Adapalene + BPO) Topical combination of potent anti-inflammatory and anti-microbial properties",@"Brightening Night Comfort Cream Fast-absorbing cream for intense skin hydration ",@"Cetaphil Sun SPF 50+ Light Gel Light weight gel that protects skin from UVA and UVB rays"];
    
    answers3Label = @[@"Skin Restoring Wash Cleanser that soothes very dry and itchy skin",@"Desowen (Desonide) Cream and Lotion Relieves inflammatory and pruritic manifestations of corticosteroid-responsive dermatoses",@"Skin Restoring Moisturizer Formula that improves skin moisture levels for a full 24 hours",@"Cetaphil Sun SPF 50+ Light Gel Light weight gel that protects skin from UVA and UVB rays"];
    
    answers4Label = @[@"Brightness Reveal Creamy Cleanser Non-drying cleanser that removes dead skin and impurities",@"Perfecting Serum Formulation that evens skin tone and improves fine lines for a fresh, well-rested skin",@"Brightness Reveal Toner and Instant Radiance Mask Formula that illuminates skin complexion and face mask that addresses skin evenness, fine lines, and texture",@"Brightening Day Protection Cream SPF15 or Brightening Night Comfort Cream Fast-absorbing cream with sun filters and hydrates sensitive skin"];
    
    choice1 = @[@"AD_DERMA_MOISTURIZER1",@"AKLIEF1",@"BENZAC1",@"DESONIDE1",@"GCS1",@"SUN_SPF1"];
    
    choice2 = @[@"AD_DERMA_MOISTURIZER2",@"BENZAC2",@"BENZOYL2",@"BHR_CREAMY_CLEANSER2",@"BHR_NIGHT_CREAM2",@"SUN_SPF2"];
    
    choice3 = @[@"AD_DERMA_MOISTURIZER3",@"AD_DERMA3",@"BENZOYL3",@"BHR_CREAMY_CLEANSER3",@"DESONIDE3",@"SUN_SPF3"];
    
    choice4 = @[@"AD_DERMA_MOISTURIZER4",@"AD_DERMA4",@"BHR_CREAMY_CLEANSER4-1",@"BHR_CREAMY_CLEANSER4",@"SPF_15_&_NIGHT4",@"TONER_&_MASK4"];
    
    choice1label = @[@"Curated for Acne Skin",@"An ideal skincare regimen tailor-fit to safety and effectively manage patients with face and truncal acne."];
    
    choice2label = @[@"Curated for Facial Acne",@"An ideal skincare regiment for patients with facial acne at risk of scaring"];
    
    choice3label = @[@"Curated for Eczema",@"An ideal skincare routine to effectively manage the signs and symptoms of Eczema."];
    
    choice4label = @[@"Curated for Uneven Skintone",@"A skincare routine formulated to address multiple types of skin discoloration such as dry patches, built-up dead skin cells, fine lines, or blotchiness."];
    
    UIImageView *mainBG = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    mainBG.image = [UIImage imageNamed:@"Product_slot_bg"];
    [self.view addSubview:mainBG];
    
    UIView *container1 = [[UIView alloc] initWithFrame:CGRectMake((width/2)-175, (height/2)-((height-def1)/2), (width/1.6)-50, height-def1)];
    
//    container1.backgroundColor = [UIColor colorWithRed:66.0f/255.0f
//                                                 green:79.0f/255.0f
//                                                  blue:91.0f/255.0f
//                                                 alpha:0.5f];
    
    [self.view addSubview:container1];
    
    UIView *container2 = [[UIView alloc] initWithFrame:CGRectMake(50, (height/2),width-((width/1.6)+95), container1.frame.size.height/2)];

    [self.view addSubview:container2];
    NSArray *myArr = [self choiceArray:self.type];
    
    NSArray *textArr = [self textArray:self.type];
    
    titleTreat = [UILabel new];
    titleTreat.text = [NSString stringWithFormat:@"%@",textArr[0]];
    titleTreat.textColor = [UIColor blackColor];
    titleTreat.backgroundColor = [UIColor clearColor];
    [titleTreat setFont:[UIFont boldSystemFontOfSize:18]];
    [self.view addSubview: titleTreat];
    titleTreat.frame  = CGRectMake(50, 200,width-((width/1.6)+95),52);
    
    titleTreatDetail = [UILabel new];
    titleTreatDetail.text = [NSString stringWithFormat:@"%@",textArr[1]];
    titleTreatDetail.textColor = [UIColor blackColor];
    titleTreatDetail.numberOfLines = 1000;
    titleTreatDetail.textAlignment = NSTextAlignmentLeft;
    titleTreatDetail.backgroundColor = [UIColor clearColor];
    [titleTreatDetail setFont:[UIFont systemFontOfSize:14]];
    [self.view addSubview: titleTreatDetail];
    titleTreatDetail.frame  = CGRectMake(50, 200+60,width-((width/1.6)+95),150);
    [titleTreatDetail sizeToFit];
    
    ivSource1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",myArr[0]]]];
    [ivSource1 setFrame:CGRectMake(60, (height/2), 100, 100)];
    [ivSource1 setTag:100];
    [ivSource1 setUserInteractionEnabled:YES];
    [self.view addSubview:ivSource1];
    
    ivSource2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",myArr[1]]]];
    [ivSource2 setFrame:CGRectMake(60+100, (height/2), 100, 100)];
    [ivSource2 setTag:101];
    [ivSource2 setUserInteractionEnabled:YES];
    [self.view addSubview:ivSource2];
    
    ivSource3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:myArr[2]]];
    [ivSource3 setFrame:CGRectMake(60+200, (height/2), 100, 100)];
    [ivSource3 setTag:102];
    [ivSource3 setUserInteractionEnabled:YES];
    [self.view addSubview:ivSource3];
    
    ivSource4 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",myArr[3]]]];
    [ivSource4 setFrame:CGRectMake(60, (height/2)+150, 100, 100)];
    [ivSource4 setTag:103];
    [ivSource4 setUserInteractionEnabled:YES];
    [self.view addSubview:ivSource4];
    
    ivSource5 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",myArr[4]]]];
    [ivSource5 setFrame:CGRectMake(60+100, (height/2)+150, 100, 100)];
    [ivSource5 setTag:104];
    [ivSource5 setUserInteractionEnabled:YES];
    [self.view addSubview:ivSource5];
    
    ivSource6 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",myArr[5]]]];
    [ivSource6 setFrame:CGRectMake(60+200, (height/2)+150, 100, 100)];
    [ivSource6 setTag:105];
    [ivSource6 setUserInteractionEnabled:YES];
    [self.view addSubview:ivSource6];

    ivDestination1 = [[UIImageView alloc] init];
    [ivDestination1 setFrame:CGRectMake((width/2)-175, 300, 160, 290)];
    [ivDestination1 setTag:200];
    ivDestination1.backgroundColor = [UIColor clearColor];
    [ivDestination1 setUserInteractionEnabled:YES];
    [self.view addSubview:ivDestination1];
    
    UILabel *detailTextProduct1 = [[UILabel alloc] init];
    [detailTextProduct1 setFrame:CGRectMake((width/2)-175, 200+ivDestination1.frame.size.height, 160, 290)];
    detailTextProduct1.textAlignment = NSTextAlignmentCenter;
    [detailTextProduct1 setTag:500];
    [detailTextProduct1 setFont:[UIFont systemFontOfSize:12]];
    detailTextProduct1.backgroundColor = [UIColor clearColor];
    detailTextProduct1.numberOfLines = 1000;
    detailTextProduct1.textColor = [UIColor blackColor];
    [self.view addSubview:detailTextProduct1];
    
    UIImageView *imgHead1 = [[UIImageView alloc] init];
    [imgHead1 setFrame:CGRectMake((width/2)-140, 180, 100, 100)];
    [imgHead1 setImage:[UIImage imageNamed:@"CLEANSE_ICON"]];
    imgHead1.backgroundColor = [UIColor clearColor];
    [imgHead1 setUserInteractionEnabled:YES];
    [self.view addSubview:imgHead1];
    
    imgIsCorrect1 = [[UIImageView alloc] init];
    [imgIsCorrect1 setFrame:CGRectMake((width/2)-140, 50, 100, 100)];
    imgIsCorrect1.backgroundColor = [UIColor clearColor];
    imgIsCorrect1.tag = 700;
    [self.view addSubview:imgIsCorrect1];
    
    ivDestination2 = [[UIImageView alloc] init];
    [ivDestination2 setFrame:CGRectMake(((width/2)-175)+160, 280, 160, 290)];
    [ivDestination2 setTag:201];
    ivDestination2.backgroundColor = [UIColor clearColor];
    [ivDestination2 setUserInteractionEnabled:YES];
    [self.view addSubview:ivDestination2];
    
    UILabel *detailTextProduct2 = [[UILabel alloc] init];
    [detailTextProduct2 setFrame:CGRectMake(((width/2)-175)+160, ivDestination2.frame.size.height+200, 160, 290)];
    detailTextProduct2.textAlignment = NSTextAlignmentCenter;
    [detailTextProduct2 setTag:501];
    [detailTextProduct2 setFont:[UIFont systemFontOfSize:12]];
    detailTextProduct2.backgroundColor = [UIColor clearColor];
    detailTextProduct2.numberOfLines = 1000;
    detailTextProduct2.textColor = [UIColor blackColor];
    [self.view addSubview:detailTextProduct2];
    
    UIImageView *imgHead2 = [[UIImageView alloc] init];
    [imgHead2 setFrame:CGRectMake(((width/2)-175)+190, 150, 100, 100)];
    [imgHead2 setImage:[UIImage imageNamed:@"TREAT_ICON"]];
    imgHead2.backgroundColor = [UIColor clearColor];
    [imgHead2 setUserInteractionEnabled:YES];
    [self.view addSubview:imgHead2];
    
    imgIsCorrect2 = [[UIImageView alloc] init];
    [imgIsCorrect2 setFrame:CGRectMake(((width/2)-175)+190, 50, 100, 100)];
    imgIsCorrect2.backgroundColor = [UIColor clearColor];
    imgIsCorrect2.tag = 701;
    [self.view addSubview:imgIsCorrect2];
    
    ivDestination3 = [[UIImageView alloc] init];
    [ivDestination3 setFrame:CGRectMake(((width/2)-175)+(160*2), 300, 160, 290)];
    [ivDestination3 setTag:202];
    ivDestination3.backgroundColor = [UIColor clearColor];
    [ivDestination3 setUserInteractionEnabled:YES];
    [self.view addSubview:ivDestination3];
    
    UILabel *detailTextProduct3 = [[UILabel alloc] init];
    [detailTextProduct3 setFrame:CGRectMake(((width/2)-175)+(160*2), ivDestination3.frame.size.height+210, 160, 290)];
    detailTextProduct3.textAlignment = NSTextAlignmentCenter;
    [detailTextProduct3 setTag:502];
    [detailTextProduct3 setFont:[UIFont systemFontOfSize:12]];
    detailTextProduct3.backgroundColor = [UIColor clearColor];
    detailTextProduct3.numberOfLines = 1000;
    detailTextProduct3.textColor = [UIColor blackColor];
    [self.view addSubview:detailTextProduct3];
    
    UIImageView *imgHead3 = [[UIImageView alloc] init];
    [imgHead3 setFrame:CGRectMake(((width/2)-175)+((190*2)-40), 180, 100, 100)];
    [imgHead3 setImage:[UIImage imageNamed:@"MOISTURISE_ICON"]];
    imgHead3.backgroundColor = [UIColor clearColor];
    [imgHead3 setUserInteractionEnabled:YES];
    [self.view addSubview:imgHead3];
    
    imgIsCorrect3 = [[UIImageView alloc] init];
    [imgIsCorrect3 setFrame:CGRectMake(((width/2)-175)+((190*2)-40), 50, 100, 100)];
    imgIsCorrect3.tag = 702;
    imgIsCorrect3.backgroundColor = [UIColor clearColor];
    [self.view addSubview:imgIsCorrect3];
    
    ivDestination4 = [[UIImageView alloc] init];
    [ivDestination4 setFrame:CGRectMake(((width/2)-175)+(160*2.9), 280, 160, 290)];
    [ivDestination4 setTag:203];
    ivDestination4.backgroundColor = [UIColor clearColor];
    [ivDestination4 setUserInteractionEnabled:YES];
    [self.view addSubview:ivDestination4];
    
    UILabel *detailTextProduct4 = [[UILabel alloc] init];
    [detailTextProduct4 setFrame:CGRectMake(((width/2)-170)+(160*2.9)+10, ivDestination4.frame.size.height+200, 160, 290)];
    detailTextProduct4.textAlignment = NSTextAlignmentCenter;
    [detailTextProduct4 setTag:503];
    [detailTextProduct4 setFont:[UIFont systemFontOfSize:12]];
    detailTextProduct4.backgroundColor = [UIColor clearColor];
    detailTextProduct4.numberOfLines = 1000;
    detailTextProduct4.textColor = [UIColor blackColor];
    [self.view addSubview:detailTextProduct4];

    UIImageView *imgHead4 = [[UIImageView alloc] init];
    [imgHead4 setFrame:CGRectMake(((width/2)-175)+((160*2.9)+40), 150, 100, 100)];
    [imgHead4 setImage:[UIImage imageNamed:@"PROTECT_ICON"]];
    imgHead4.backgroundColor = [UIColor clearColor];
    [imgHead4 setUserInteractionEnabled:YES];
    [self.view addSubview:imgHead4];
    
    imgIsCorrect4 = [[UIImageView alloc] init];
    [imgIsCorrect4 setFrame:CGRectMake(((width/2)-175)+((160*2.9)+40), 50, 100, 100)];
    imgIsCorrect4.tag = 703;
    imgIsCorrect4.backgroundColor = [UIColor clearColor];
    [self.view addSubview:imgIsCorrect4];
    
    tempIV = [[UIImageView alloc] init];
    [tempIV setFrame:CGRectMake(0, 300, 100, 100)];
    [tempIV setTag:500];
    tempIV.backgroundColor = [UIColor clearColor];
    [tempIV setUserInteractionEnabled:YES];
    [self.view addSubview:tempIV];
    
    UIButton *btnMenu = [UIButton new];
    [btnMenu setImage:[UIImage imageNamed:@"HOME"] forState:normal];
    [self.view addSubview:btnMenu];
    [btnMenu addTarget:self action:@selector(VoidHome) forControlEvents:UIControlEventTouchUpInside];
    btnMenu.frame = CGRectMake(width-200, height-60, 42, 42);
    
    UIButton *btnBack = [UIButton new];
    [btnBack setImage:[UIImage imageNamed:@"BACK"] forState:normal];
    [self.view addSubview:btnBack];
    [btnBack addTarget:self action:@selector(VoidBack) forControlEvents:UIControlEventTouchUpInside];
    btnBack.frame = CGRectMake(width-150, height-60, 42, 42);
    
    UIButton *btnNext = [UIButton new];
    [btnNext setImage:[UIImage imageNamed:@"NEXT"] forState:normal];
    [self.view addSubview:btnNext];
    [btnNext addTarget:self action:@selector(VoidNext) forControlEvents:UIControlEventTouchUpInside];
    btnNext.frame = CGRectMake(width-100, height-60, 42, 42);
    
    btnSubmitAnswer = [UIButton new];
    [btnSubmitAnswer setImage:[UIImage imageNamed:@"submit"] forState:normal];
    [self.view addSubview:btnSubmitAnswer];
    btnSubmitAnswer.hidden = YES;
    [btnSubmitAnswer addTarget:self action:@selector(VoidSubmitAnswer) forControlEvents:UIControlEventTouchUpInside];
    btnSubmitAnswer.frame = CGRectMake(width-250, height-150, 140, 42);
    
    
    imgTimer = [[UIImageView alloc] init];
    [imgTimer setFrame:CGRectMake(width/2, height-200, 100, 100)];
    [imgTimer setImage:[UIImage imageNamed:@"timer"]];
    imgTimer.backgroundColor = [UIColor clearColor];
    [imgTimer setUserInteractionEnabled:YES];
    [self.view addSubview:imgTimer];
    
    timerLabel = [UILabel new];
    timerLabel.text = [NSString stringWithFormat:@"%d",counter];
    timerLabel.textAlignment = NSTextAlignmentCenter;
    [timerLabel setFont:[UIFont boldSystemFontOfSize:48]];
    [self.view addSubview:timerLabel];
    timerLabel.frame = CGRectMake(width/2, height-200, 100, 100);
    
    scoreBoard = [UIView new];
    scoreBoard.backgroundColor = [UIColor blackColor];
    [self.view addSubview:scoreBoard];
    
    scoreBoard.frame = CGRectMake(60, height-220,200, 100);

    CAShapeLayer * maskLayer = [CAShapeLayer layer];
    maskLayer.path = [UIBezierPath bezierPathWithRoundedRect: scoreBoard.bounds byRoundingCorners: UIRectCornerBottomLeft | UIRectCornerTopRight cornerRadii: (CGSize){50, 50}].CGPath;

    scoreBoard.hidden = YES;
    scoreBoard.layer.mask = maskLayer;
    
    finalScoreLabel = [UILabel new];
    finalScoreLabel.text = @"";
    finalScoreLabel.textAlignment = NSTextAlignmentCenter;
    [finalScoreLabel setFont:[UIFont boldSystemFontOfSize:24]];
    finalScoreLabel.textColor = [UIColor whiteColor];
    [self.view addSubview:finalScoreLabel];
    finalScoreLabel.frame = CGRectMake(60, height-220,200, 100);
}



-(void)VoidHome{
    if(isHomeEnabled){
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}
-(void)VoidBack{
//    [self.navigationController popViewControllerAnimated:YES];
}
-(void)VoidNext{
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(submitted)
        return;
    
    UITouch *touch = [touches anyObject];

    if([[touch view] tag] == 100 && answerCount<4)
    {
        ivSource1.hidden = YES;
        ivSource1.userInteractionEnabled = NO;
        [tempIV setImage:ivSource1.image];
        [tempIV setCenter:[touch locationInView:self.view]];
        tempIV.tag = 100;
    }
    
    if([[touch view] tag] == 101 && answerCount<4)
    {
        ivSource2.hidden = YES;
        ivSource2.userInteractionEnabled = NO;
        [tempIV setImage:ivSource2.image];
        [tempIV setCenter:[touch locationInView:self.view]];
        tempIV.tag = 101;
    }
    
    if([[touch view] tag] == 102 && answerCount<4)
    {
        ivSource3.hidden = YES;
        ivSource3.userInteractionEnabled = NO;
        [tempIV setImage:ivSource3.image];
        [tempIV setCenter:[touch locationInView:self.view]];
        tempIV.tag = 102;
    }
    
    if([[touch view] tag] == 103 && answerCount<4)
    {
        ivSource4.hidden = YES;
        ivSource4.userInteractionEnabled = NO;
        [tempIV setImage:ivSource4.image];
        [tempIV setCenter:[touch locationInView:self.view]];
        tempIV.tag = 103;
    }
    
    if([[touch view] tag] == 104 && answerCount<4)
    {
        ivSource5.hidden = YES;
        ivSource5.userInteractionEnabled = NO;
        [tempIV setImage:ivSource5.image];
        [tempIV setCenter:[touch locationInView:self.view]];
        tempIV.tag = 104;
    }
    
    if([[touch view] tag] == 105 && answerCount<4)
    {
        ivSource6.hidden = YES;
        ivSource6.userInteractionEnabled = NO;
        [tempIV setImage:ivSource6.image];
        [tempIV setCenter:[touch locationInView:self.view]];
        tempIV.tag = 105;
    }
}

-(NSArray*)answerDetailLabelArray:(int)type{
    NSArray *arr;
    switch (type) {
        case 1:
            arr = answers1Label;
            break;
        case 2:
            arr = answers2Label;
            break;
        case 3:
            arr = answers3Label;
            break;
        case 4:
            arr = answers4Label;
            break;
    }
    return arr;
}

-(NSArray*)textArray:(int)type{
    NSArray *arr;
    switch (type) {
        case 1:
            arr = choice1label;
            break;
        case 2:
            arr = choice2label;
            break;
        case 3:
            arr = choice3label;
            break;
        case 4:
            arr = choice4label;
            break;
    }
    return arr;
}

-(NSArray*)choiceArray:(int)type{
    NSArray *arr;
    switch (type) {
        case 1:
            arr = choice1;
            break;
        case 2:
            arr = choice2;
            break;
        case 3:
            arr = choice3;
            break;
        case 4:
            arr = choice4;
            break;
    }
    return arr;
}

-(NSArray*)correctAnsArray:(int)type{
    NSArray *arr;
    switch (type) {
        case 1:
            arr = _answers1;
            break;
        case 2:
            arr = _answer2;
            break;
        case 3:
            arr = _answer3;
            break;
        case 4:
            arr = _answers4;
            break;
    }
    return arr;
}

- (void)resetSource:(int)tag{
    switch (tag) {
        case 100:{
            ivSource1.hidden = NO;
            ivSource1.userInteractionEnabled = YES;
            break;
        }
        case 101:{
            ivSource2.hidden = NO;
            ivSource2.userInteractionEnabled = YES;
            break;
        }
        case 102:{
            ivSource3.hidden = NO;
            ivSource3.userInteractionEnabled = YES;
            break;
        }
        case 103:{
            ivSource4.hidden = NO;
            ivSource4.userInteractionEnabled = YES;
            break;
        }
        case 104:{
            ivSource5.hidden = NO;
            ivSource5.userInteractionEnabled = YES;
            break;
        }
        case 105:{
            ivSource6.hidden = NO;
            ivSource6.userInteractionEnabled = YES;
            break;
        }
        default:
            tempIV.tag = 500;
            break;
            

    }
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];

    [tempIV setCenter:[touch locationInView:self.view]];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    UITouch *touch = [touches anyObject];
    [tempIV setCenter:[touch locationInView:self.view]];
    
    NSArray *arrA = [self choiceArray:self.type];

    if(!CGRectContainsPoint(ivDestination4.frame, [touch locationInView:self.view])&& !CGRectContainsPoint(ivDestination3.frame, [touch locationInView:self.view])&& !CGRectContainsPoint(ivDestination2.frame, [touch locationInView:self.view]) &&!CGRectContainsPoint(ivDestination1.frame, [touch locationInView:self.view]) && answerCount<4){
        [self resetSource:(int)tempIV.tag];
    }
    
    if(CGRectContainsPoint(ivDestination1.frame, [touch locationInView:self.view]) && tempIV.image && answerCount<4 && !ivDestination1.image)
    {
        [ivDestination1 setImage:tempIV.image];
        answerCount +=1;
        [finalAnswers addObject:arrA[(int)tempIV.tag-100]];
    }else if (CGRectContainsPoint(ivDestination1.frame, [touch locationInView:self.view]) && ivDestination1.image&& answerCount<4){
        [self resetSource:(int)tempIV.tag];
    }
    
    if(CGRectContainsPoint(ivDestination2.frame, [touch locationInView:self.view])&& tempIV.image&& answerCount<4 && !ivDestination2.image)
   {
       [ivDestination2 setImage:tempIV.image];
       answerCount +=1;
       [finalAnswers addObject:arrA[(int)tempIV.tag-100]];
   }else if(CGRectContainsPoint(ivDestination2.frame, [touch locationInView:self.view])&&ivDestination2.image&& answerCount<4){
        [self resetSource:(int)tempIV.tag];
   }
    
    if(CGRectContainsPoint(ivDestination3.frame, [touch locationInView:self.view])&& tempIV.image && answerCount<4 && !ivDestination3.image)
    {
        [ivDestination3 setImage:tempIV.image];
        answerCount +=1;
        [finalAnswers addObject:arrA[(int)tempIV.tag-100]];
    }else if(CGRectContainsPoint(ivDestination3.frame, [touch locationInView:self.view])&&ivDestination3.image&& answerCount<4){
        [self resetSource:(int)tempIV.tag];
    }
    
    if(CGRectContainsPoint(ivDestination4.frame, [touch locationInView:self.view])&& tempIV.image&& answerCount<4 && !ivDestination4.image)
    {
        [ivDestination4 setImage:tempIV.image];
        answerCount +=1;
        [finalAnswers addObject:arrA[(int)tempIV.tag-100]];
    }else if(CGRectContainsPoint(ivDestination4.frame, [touch locationInView:self.view])&&ivDestination4.image&& answerCount<4){
        [self resetSource:(int)tempIV.tag];
    }
    
    [tempIV setImage:[UIImage imageNamed:@""]];
    [tempIV setFrame:CGRectMake(0, 300, 100, 100)];
    
    if(finalAnswers.count > 0){
        btnSubmitAnswer.hidden = NO;
    }
}

-(void)VoidSubmitPlay{

}


@end

