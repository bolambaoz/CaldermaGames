//
//  Page2ViewController.m
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//
#import "Page2ViewController.h"
#import "Page3ViewController.h"

@interface Page2ViewController ()<UITextFieldDelegate>

@end

@implementation Page2ViewController{

    float width;
    float height;
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.navigationItem.setHidesBackButton(true, animated: true)

    [self.navigationItem setHidesBackButton:YES];
    
    
    width =  self.view.frame.size.width;
    height = self.view.frame.size.height;
    float def1 = 100;
    UIImageView *mainBG = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    mainBG.image = [UIImage imageNamed:@"main_bg"];
    [self.view addSubview:mainBG];
    
    UIView *container = [[UIView alloc] initWithFrame:CGRectMake((width/2)-((width-def1)/2), (height/2)-((height-def1)/2), width-def1, height-def1)];
    container.backgroundColor = [UIColor clearColor];
    [self.view addSubview:container];
    
    float imgW=container.frame.size.width/4;
    NSArray *images = @[@"ACNE_SKIN_MODEL",@"ECZEMA_MODEL",@"FACIAL_ACNE_MODEL",@"UNEVEN_SKINTONE_MODEL"];
    for(int i=0; i<images.count; i++){
        UIButton *imgBtn = [[UIButton alloc] initWithFrame:CGRectMake(50+(((imgW+5)*i)), (height/3.5), imgW-20, height/2.5)];
        imgBtn.tag = 101 + i;
        [imgBtn setImage:[UIImage imageNamed:images[i]] forState:normal];
        imgBtn.imageView.contentMode = UIViewContentModeScaleAspectFill;
        [self.view addSubview:imgBtn];
        imgBtn.layer.borderColor = [UIColor blackColor].CGColor;
        imgBtn.layer.borderWidth = 1;
        imgBtn.layer.cornerRadius = 10;
        imgBtn.layer.masksToBounds = YES;
        
        [imgBtn addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    UIButton *btnMenu = [UIButton new];
    [btnMenu setImage:[UIImage imageNamed:@"HOME"] forState:normal];
    [self.view addSubview:btnMenu];
    [btnMenu addTarget:self action:@selector(VoidHome) forControlEvents:UIControlEventTouchUpInside];
    btnMenu.frame = CGRectMake(width-200, height-60, 42, 42);
    
    UIButton *btnBack = [UIButton new];
    [btnBack setImage:[UIImage imageNamed:@"BACK"] forState:normal];
    [self.view addSubview:btnBack];
    [btnBack addTarget:self action:@selector(VoidBack) forControlEvents:UIControlEventTouchUpInside];
    btnBack.frame = CGRectMake(width-150, height-60, 42, 42);
    
    UIButton *btnNext = [UIButton new];
    [btnNext setImage:[UIImage imageNamed:@"NEXT"] forState:normal];
    [self.view addSubview:btnNext];
    [btnNext addTarget:self action:@selector(VoidNext) forControlEvents:UIControlEventTouchUpInside];
    btnNext.frame = CGRectMake(width-100, height-60, 42, 42);
    
    
}

-(void)VoidHome{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)VoidBack{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)VoidNext{
    
}

-(void)BtnClick:(id)sender{
    UIButton *btn = sender;
    int type = (int)btn.tag - 100;
    Page3ViewController *page3 = [Page3ViewController new];
    page3.type = type;
    
    [self.navigationController pushViewController:page3 animated:true];
    
}

-(void)VoidSubmitPlay{
    if(self.navigationController != nil){
        Page3ViewController *page2 = [Page3ViewController new];
        [self.navigationController pushViewController:page2 animated:true];
    }
}


@end
