//
//  ViewController.m
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//

#import "Page1ViewController.h"
#import "Page2ViewController.h"


#define def_userKey  username

@interface Page1ViewController ()<UITextFieldDelegate>

@end

@implementation Page1ViewController{
    UITextField *Name;
    UITextField *Phone;
    
    UIButton *btnPlay;
    
    NSString *userName;
    NSString *userPhone;
    
    UIAlertController  *alert;
    
    float width;
    float height;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    width =  self.view.frame.size.width;
    height = self.view.frame.size.height;
    
    UIImageView *mainBG = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    mainBG.image = [UIImage imageNamed:@"main_bg"];
    [self.view addSubview:mainBG];
    
    UIButton *imgNameList = [[UIButton alloc] initWithFrame:CGRectMake(width-50, height-50, 32,32)];
    [imgNameList setImage:[UIImage imageNamed:@"nameList"] forState:normal];
    [imgNameList addTarget:self action:@selector(VoidShowNames) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:imgNameList];
    
    
    
    Name = [[UITextField alloc] init];
    [Name setFrame:CGRectMake((width/2)-150, (height/3), 300, 52)];
    [Name setTag:100];
    Name.backgroundColor = [UIColor whiteColor];
    Name.placeholder = @" User name";
    [Name setUserInteractionEnabled:YES];
    [self.view addSubview:Name];
    Name.delegate = self;
    Name.layer.cornerRadius = 10;
    Name.layer.borderColor = [UIColor blackColor].CGColor;
    Name.layer.borderWidth = 1;
    Name.layer.masksToBounds = YES;
    
    Phone = [[UITextField alloc] init];
    [Phone setFrame:CGRectMake((width/2)-150, (height/3)+60, 300, 52)];
    [Phone setTag:100];
    Phone.delegate = self;
    Phone.keyboardType = UIKeyboardTypeNumberPad;
    Phone.backgroundColor = [UIColor whiteColor];
    Phone.placeholder = @" phone number (optional)";
    Phone.layer.cornerRadius = 10;
    Phone.layer.borderColor = [UIColor blackColor].CGColor;
    Phone.layer.borderWidth = 1;
    Phone.layer.masksToBounds = YES;
    [Phone setUserInteractionEnabled:YES];
    [self.view addSubview:Phone];
    
    btnPlay = [[UIButton alloc] initWithFrame:CGRectMake((width/2)-150, (height/3)+200, 300, 54)];
    [btnPlay setImage:[UIImage imageNamed:@"SUBMIT_PLAY"] forState:normal];
    btnPlay.imageView.contentMode = UIViewContentModeScaleAspectFill;
    [btnPlay addTarget:self action:@selector(VoidSubmitPlay) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnPlay];
    
    btnPlay.layer.cornerRadius = 10;
    btnPlay.layer.masksToBounds = YES;
    
    alert = [UIAlertController alertControllerWithTitle:@"My Alert"
                                   message:@"This is an alert."
                                   preferredStyle:UIAlertControllerStyleAlert];

    alert = [UIAlertController alertControllerWithTitle:@"User name"
                message:@"Please input a username."
                preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *firstAction = [UIAlertAction actionWithTitle:@"OK"
                style:UIAlertActionStyleDefault handler:nil];

    [alert addAction:firstAction];

        
    

}

- (void)VoidShowNames{
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"%@",textField.text);
    if (textField == Name) {
        userName = [NSString stringWithFormat:@"%@", textField.text];
    }
    else if (textField == Phone) {
        userPhone = [NSString stringWithFormat:@"%@", textField.text];
    }
}

-(void)VoidSubmitPlay{
    
    if(Name.text){
//        [self saveUsername];
        Page2ViewController *page2 = [Page2ViewController new];
        [self.navigationController pushViewController:page2 animated:true];
    }else{
        [self presentViewController:alert animated:YES completion:nil]; // 6
    }
}

-(void)saveUsername{
    NSString *str=[NSString stringWithFormat:@"%@/%@",Name.text,Phone.text];
    
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    NSArray *arr1 = [userDef objectForKey:@"userArrayInfo"];
    
    NSMutableArray *temp;
    [temp addObject:arr1];
    
    [[NSUserDefaults standardUserDefaults] objectForKey:@"userArrayInfo"];
    NSArray *arrFinal = temp;
    
    [userDef setObject:arrFinal forKey:@"userArrayInfo"];
    [userDef synchronize];
    
        
    NSUserDefaults *us = [NSUserDefaults standardUserDefaults];
    NSArray *arr = [us objectForKey:@"userArrayInfo"];
    for (int i=0; i<arr.count; i++) {
                NSLog(@"%@",arr[i]);
    }
    
//    NSUserDefaults *us = [NSUserDefaults standardUserDefaults];
//    NSMutableArray *arr = [us objectForKey:@"userArrayInfo"];
//    for (int i=0; i<arr.count; i++) {
//        NSLog(@"%@",arr[i]);
//    }

}




@end
