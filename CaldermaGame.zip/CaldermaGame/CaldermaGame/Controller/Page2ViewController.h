//
//  Page2ViewController.h
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//

#import <UIKit/UIKit.h>

@interface Page2ViewController : UIViewController


@end
