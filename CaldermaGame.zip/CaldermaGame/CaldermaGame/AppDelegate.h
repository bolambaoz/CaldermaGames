//
//  AppDelegate.h
//  CaldermaGame
//
//  Created by Zebedee Bolambao on 5/13/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

